
def main():
    print('Place holder for command line interface')
